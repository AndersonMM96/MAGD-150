function setup() {
  createCanvas(800, 800);
  colorMode(RGB, 255);
  noStroke();
  frameRate(60);
}

let randR = 100;
let randG = 100;
let randB = 100;
let chance = 2;
let circles = [];

function draw() {
  //clear
  background(0);
  //update random variables
  //1 in [chance] chance for each variable to update every frame
  if(int(random(0, chance)) == 0)
  {
    randR++;
  }
  if(int(random(0, chance)) == 0)
  {
    randG++;
  }
  if(int(random(0, chance)) == 0)
  {
    randB++;
  }
  
  //create new circle if mouse is moved
  if(mouseX != pmouseX || mouseY != pmouseY)
  {
    circles.push(new Circle());
  }
  
  //update each circle
  for (let i = 0; i < circles.length; i++) 
  {
    if(circles[i].update())
    {
      circles.shift();
    }
    else
    {
      circles[i].display();
    }
  }
  
}

function mouseClicked() {
  //set colors to random
  randR = int(random(0, 256));
  randG = int(random(0, 256));
  randB = int(random(0, 256));
  
  circles.push(new Circle());
}

class Circle {
  constructor() {
    this.x = mouseX;
    this.y = mouseY;
    this.speed = dist(mouseX, mouseY, pmouseX, pmouseY) / sqrt(400);
    this.size = 0;
    this.r = randR;
    this.g = randG;
    this.b = randB;
  }
  
  update()
  {
    this.size += this.speed;
    
    if(this.size > 255)
    {
      return true;
    }
    return false;
  }

  display() {
    fill(this.r, this.g, this.b, 255 - this.size);
    ellipse(this.x, this.y, this.size, this.size);
  }
}
