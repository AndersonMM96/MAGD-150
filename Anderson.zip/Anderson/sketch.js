function setup() 
{
  createCanvas(800, 800);
}

function draw() 
{
	stroke(51);
	strokeJoin(MITER);
	strokeWeight(10.0);

	//bg
	background(120);

	//moon
	fill(250);
	stroke(225);
	strokeWeight(100.0);
	point(100, 100);
	stroke(51);
	strokeWeight(10.0);

	//road
	fill(50);
	rect(0, 600, 800, 800);

	//road lines
	stroke(151);
	line(0, 700, 100, 700);
	line(150, 700, 250, 700);
	line(300, 700, 400, 700);
	line(450, 700, 550, 700);
	line(600, 700, 700, 700);
	line(750, 700, 800, 700);
	stroke(51);

	//buildings
	strokeJoin(BEVEL);
	fill(150);
	rect(70, 200, 250, 400);
	rect(350, 100, 250, 500);
	rect(500, 300, 200, 300);
	strokeJoin(MITER);

	//windows
	noStroke();
	fill(250);
	rect(100, 220, 60, 60);
	rect(220, 220, 60, 60);
	rect(100, 300, 60, 60);
	rect(220, 300, 60, 60);
	rect(100, 380, 60, 60);
	rect(220, 380, 60, 60);
	
	rect(380, 130, 60, 60);
	rect(450, 130, 60, 60);
	rect(520, 130, 60, 60);
	rect(380, 210, 60, 60);
	rect(450, 210, 60, 60);
	rect(520, 210, 60, 60);

	stroke(51);

	//car
	fill(180);
	strokeJoin(ROUND);
	beginShape();
	vertex(10, 650);
	vertex(250, 650);
	vertex(230, 610);
	vertex(200, 600);
	vertex(125, 570);
	vertex(10, 600);
	vertex(10, 650);
	vertex(10, 600);

	endShape();
	//wheels
	fill(75);
	ellipse(50, 650, 55, 55);
	ellipse(200, 650, 55, 55);


	

}