function setup() 
{
  createCanvas(400, 400);
}

function draw() 
{
  //black background
  background(60);
  
  strokeWeight(1);
  ellipseMode(CENTER);
  
  //set color mode
  colorMode(RGB, 255, 255, 255, 1);
  
  //draw planet 1
  stroke(5);
  fill(150, 20, 250, 1);
  ellipse(100, 100, 100, 100);
  fill(100, 20, 150, 1);
  noStroke();
  ellipse(80, 75, 20, 20);
  ellipse(130, 90, 23, 23);
  ellipse(95, 120, 15, 15);
  
  //draw planet 2
  stroke(5);
  fill(220, 200, 150, 1);
  ellipse(250, 280, 125, 120);
  fill(220, 200, 150, 0.5);
  noStroke();
  rotate(50);
  ellipse(170, 335, 250, 50);
  fill(200, 150, 150, 0.5);
  ellipse(170, 335, 250, 50);
  rotate(-50);
  
  //ufo
  fill(200, 250, 255, 1);
  arc(90, 250, 60, 50, 0, PI + PI, CHORD);
  fill(250, 250, 255, 1);
  arc(90, 250, 90, 80, 0, PI, CHORD);
  fill(0, 0, 0, 1);
  triangle(70, 260, 110, 260, 90, 280);
  
  
  //big star
  stroke(5);
  fill(250, 250, 30, 1);
  quad(300, 50, 275, 75, 300, 100, 325, 75);
  
  
  //stars
  strokeWeight(15);
  stroke(250, 250, 100, 1);
  fill(250, 250, 100, 1);
  point(200, 80);
  point(120, 190);
  point(50, 340);
  point(340, 350);
  point(350, 200);
  point(170, 220);
  
}